<?php
/**
 * db.php — MySQL Database Connection & Schema Manager
 * Disaster Intelligence Command Center
 */

define('DB_HOST', 'localhost');
define('DB_NAME', 'disaster_intelligence');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_PORT', 3306);

/* OpenWeatherMap API Key */
define('OWM_API_KEY', 'c11c675eb5f250330916e62b978fd221');

/* Cache TTLs */
define('EQ_CACHE_SECONDS',  20);
define('WX_CACHE_SECONDS',  600);

/* --- PDO Singleton --- */
function getDB(): PDO {
    static $pdo = null;
    if ($pdo) return $pdo;

    try {
        $dsn = sprintf('mysql:host=%s;port=%d;charset=utf8mb4', DB_HOST, DB_PORT);
        $pdo = new PDO($dsn, DB_USER, DB_PASS, [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES   => false,
        ]);

        /* Create database if not exists */
        $pdo->exec("CREATE DATABASE IF NOT EXISTS `" . DB_NAME . "` 
                    CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci");
        $pdo->exec("USE `" . DB_NAME . "`");

        /* Create tables */
        _createSchema($pdo);

        return $pdo;
    } catch (PDOException $e) {
        /* Return null-safe fallback — caller must handle */
        error_log('[DICC DB Error] ' . $e->getMessage());
        return null;
    }
}

function _createSchema(PDO $pdo): void {
    /* API cache table */
    $pdo->exec("CREATE TABLE IF NOT EXISTS `api_cache` (
        `id`          INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        `cache_key`   VARCHAR(100) NOT NULL UNIQUE,
        `data`        LONGTEXT NOT NULL,
        `created_at`  INT UNSIGNED NOT NULL,
        `expires_at`  INT UNSIGNED NOT NULL,
        INDEX `idx_expires` (`expires_at`),
        INDEX `idx_key`     (`cache_key`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

    /* Earthquake events log */
    $pdo->exec("CREATE TABLE IF NOT EXISTS `earthquakes` (
        `id`          VARCHAR(50) PRIMARY KEY,
        `magnitude`   FLOAT NOT NULL,
        `place`       VARCHAR(255),
        `lat`         DECIMAL(9,6),
        `lon`         DECIMAL(9,6),
        `depth`       FLOAT,
        `eq_time`     INT UNSIGNED,
        `url`         VARCHAR(512),
        `net`         VARCHAR(20),
        `alert`       VARCHAR(20),
        `tsunami`     TINYINT(1) DEFAULT 0,
        `fetched_at`  INT UNSIGNED,
        INDEX `idx_mag`     (`magnitude`),
        INDEX `idx_time`    (`eq_time`),
        INDEX `idx_lat_lon` (`lat`, `lon`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

    /* Weather data log */
    $pdo->exec("CREATE TABLE IF NOT EXISTS `weather_data` (
        `id`          INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        `city`        VARCHAR(100),
        `lat`         DECIMAL(9,6),
        `lon`         DECIMAL(9,6),
        `temperature` FLOAT,
        `feels_like`  FLOAT,
        `humidity`    SMALLINT,
        `pressure`    SMALLINT,
        `condition_text` VARCHAR(100),
        `icon`        VARCHAR(20),
        `wind_speed`  FLOAT,
        `wind_dir`    SMALLINT,
        `visibility`  INT,
        `source`      VARCHAR(50),
        `fetched_at`  INT UNSIGNED,
        INDEX `idx_city`   (`city`),
        INDEX `idx_fetch`  (`fetched_at`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
}

/* --- Cache Helpers --- */
function cacheGet(PDO $pdo, string $key): ?string {
    if (!$pdo) return null;
    try {
        $stmt = $pdo->prepare(
            "SELECT data FROM api_cache WHERE cache_key = ? AND expires_at > ? LIMIT 1"
        );
        $stmt->execute([$key, time()]);
        $row = $stmt->fetch();
        return $row ? $row['data'] : null;
    } catch (PDOException $e) {
        error_log('[DICC Cache Get] ' . $e->getMessage());
        return null;
    }
}

function cacheSet(PDO $pdo, string $key, string $data, int $ttl): bool {
    if (!$pdo) return false;
    try {
        $now     = time();
        $expires = $now + $ttl;
        $stmt = $pdo->prepare(
            "INSERT INTO api_cache (cache_key, data, created_at, expires_at)
             VALUES (?, ?, ?, ?)
             ON DUPLICATE KEY UPDATE data=VALUES(data), created_at=VALUES(created_at), expires_at=VALUES(expires_at)"
        );
        return $stmt->execute([$key, $data, $now, $expires]);
    } catch (PDOException $e) {
        error_log('[DICC Cache Set] ' . $e->getMessage());
        return false;
    }
}

/* --- Purge expired cache (run occasionally) --- */
function cachePurge(PDO $pdo): void {
    if (!$pdo) return;
    try {
        $pdo->prepare("DELETE FROM api_cache WHERE expires_at < ?")->execute([time()]);
    } catch (PDOException $e) {}
}
