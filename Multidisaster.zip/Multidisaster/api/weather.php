<?php
/**
 * weather.php — Real OpenWeatherMap API with MySQL Caching
 * Disaster Intelligence Command Center
 *
 * Uses OpenWeatherMap Current Weather API (free tier - no onecall needed)
 * Fetches 20 major global cities, caches in MySQL for 10 minutes
 */

header('Content-Type: application/json; charset=UTF-8');
header('Access-Control-Allow-Origin: *');
header('Cache-Control: no-store');

require_once __DIR__ . '/db.php';

$cacheKey = 'weather_global_v2';
$pdo      = getDB();

/* ---- MySQL cache ---- */
$cached = $pdo ? cacheGet($pdo, $cacheKey) : null;
if ($cached) { echo $cached; exit; }

/* ---- File-based fallback cache ---- */
$cacheDir  = dirname(__DIR__) . '/cache/';
$cacheFile = $cacheDir . 'weather.json';
if (!is_dir($cacheDir)) mkdir($cacheDir, 0755, true);
if (!$cached && file_exists($cacheFile) && (time() - filemtime($cacheFile)) < WX_CACHE_SECONDS) {
    $cached = file_get_contents($cacheFile);
    if ($cached) { echo $cached; exit; }
}

/* ---- Cities to monitor ---- */
$cities = [
    ['name' => 'Tokyo',        'lat' =>  35.6762, 'lon' =>  139.6503],
    ['name' => 'New York',     'lat' =>  40.7128, 'lon' =>  -74.0060],
    ['name' => 'London',       'lat' =>  51.5074, 'lon' =>   -0.1278],
    ['name' => 'Mumbai',       'lat' =>  19.0760, 'lon' =>   72.8777],
    ['name' => 'Sydney',       'lat' => -33.8688, 'lon' =>  151.2093],
    ['name' => 'Beijing',      'lat' =>  39.9042, 'lon' =>  116.4074],
    ['name' => 'Los Angeles',  'lat' =>  34.0522, 'lon' => -118.2437],
    ['name' => 'São Paulo',    'lat' => -23.5505, 'lon' =>  -46.6333],
    ['name' => 'Cairo',        'lat' =>  30.0444, 'lon' =>   31.2357],
    ['name' => 'Moscow',       'lat' =>  55.7558, 'lon' =>   37.6173],
    ['name' => 'Jakarta',      'lat' =>  -6.2088, 'lon' =>  106.8456],
    ['name' => 'Mexico City',  'lat' =>  19.4326, 'lon' =>  -99.1332],
    ['name' => 'Nairobi',      'lat' =>  -1.2921, 'lon' =>   36.8219],
    ['name' => 'Dubai',        'lat' =>  25.2048, 'lon' =>   55.2708],
    ['name' => 'Paris',        'lat' =>  48.8566, 'lon' =>    2.3522],
    ['name' => 'Delhi',        'lat' =>  28.6139, 'lon' =>   77.2090],
    ['name' => 'Singapore',    'lat' =>   1.3521, 'lon' =>  103.8198],
    ['name' => 'Istanbul',     'lat' =>  41.0082, 'lon' =>   28.9784],
    ['name' => 'Buenos Aires', 'lat' => -34.6037, 'lon' =>  -58.3816],
    ['name' => 'Lagos',        'lat' =>   6.5244, 'lon' =>    3.3792],
];

$apiKey     = OWM_API_KEY;
$hasApiKey  = !empty($apiKey) && $apiKey !== 'YOUR_OPENWEATHER_API_KEY_HERE';
$results    = [];
$dbRows     = [];

$ctx = stream_context_create([
    'http' => [
        'timeout'       => 6,
        'method'        => 'GET',
        'ignore_errors' => true,
        'user_agent'    => 'DICC/2.0',
    ],
    'ssl'  => ['verify_peer' => false, 'verify_peer_name' => false],
]);

foreach ($cities as $city) {
    $weatherData = null;

    if ($hasApiKey) {
        /* OpenWeatherMap Current Weather API (completely free) */
        $url = sprintf(
            'https://api.openweathermap.org/data/2.5/weather?lat=%s&lon=%s&appid=%s&units=metric&lang=en',
            $city['lat'], $city['lon'], urlencode($apiKey)
        );
        $raw  = @file_get_contents($url, false, $ctx);
        $json = $raw ? json_decode($raw, true) : null;

        if ($json && isset($json['main']) && ($json['cod'] ?? 0) == 200) {
            $weatherData = [
                'city'           => $city['name'],
                'lat'            => (float)$city['lat'],
                'lon'            => (float)$city['lon'],
                'temperature'    => round((float)($json['main']['temp'] ?? 0), 1),
                'feels_like'     => round((float)($json['main']['feels_like'] ?? 0), 1),
                'humidity'       => (int)($json['main']['humidity'] ?? 0),
                'pressure'       => (int)($json['main']['pressure'] ?? 0),
                'condition'      => ucfirst($json['weather'][0]['description'] ?? 'unknown'),
                'condition_id'   => (int)($json['weather'][0]['id'] ?? 800),
                'icon'           => $json['weather'][0]['icon'] ?? '01d',
                'icon_url'       => 'https://openweathermap.org/img/wn/' . ($json['weather'][0]['icon'] ?? '01d') . '@2x.png',
                'wind_speed'     => round((float)($json['wind']['speed'] ?? 0), 1),
                'wind_dir'       => (int)($json['wind']['deg'] ?? 0),
                'visibility'     => (int)($json['visibility'] ?? 10000),
                'cloudiness'     => (int)($json['clouds']['all'] ?? 0),
                'sunrise'        => (int)($json['sys']['sunrise'] ?? 0),
                'sunset'         => (int)($json['sys']['sunset'] ?? 0),
                'country'        => $json['sys']['country'] ?? '',
                'time'           => (int)($json['dt'] ?? time()),
                'source'         => 'OpenWeatherMap',
                'uv_index'       => null,
            ];
        }
    }

    /* Fallback: realistic simulated data */
    if (!$weatherData) {
        $weatherData = _simulateWeather($city);
    }

    $results[] = $weatherData;

    $dbRows[] = [
        'city'           => $weatherData['city'],
        'lat'            => $weatherData['lat'],
        'lon'            => $weatherData['lon'],
        'temperature'    => $weatherData['temperature'],
        'feels_like'     => $weatherData['feels_like'],
        'humidity'       => $weatherData['humidity'],
        'pressure'       => $weatherData['pressure'],
        'condition_text' => mb_substr($weatherData['condition'], 0, 100),
        'icon'           => mb_substr($weatherData['icon'] ?? '', 0, 20),
        'wind_speed'     => $weatherData['wind_speed'],
        'wind_dir'       => $weatherData['wind_dir'],
        'visibility'     => $weatherData['visibility'],
        'source'         => $weatherData['source'],
        'fetched_at'     => time(),
    ];
}

$output = json_encode($results, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT);

/* ---- Store in MySQL cache ---- */
if ($pdo) {
    cacheSet($pdo, $cacheKey, $output, WX_CACHE_SECONDS);

    /* Log to weather_data table */
    try {
        $pdo->exec("USE `" . DB_NAME . "`");
        $stmt = $pdo->prepare(
            "INSERT INTO weather_data
             (city,lat,lon,temperature,feels_like,humidity,pressure,condition_text,icon,wind_speed,wind_dir,visibility,source,fetched_at)
             VALUES (:city,:lat,:lon,:temperature,:feels_like,:humidity,:pressure,:condition_text,:icon,:wind_speed,:wind_dir,:visibility,:source,:fetched_at)"
        );
        foreach ($dbRows as $row) {
            $stmt->execute($row);
        }
    } catch (PDOException $e) {
        error_log('[DICC WX DB] ' . $e->getMessage());
    }
}

/* File backup */
file_put_contents($cacheFile, $output);
echo $output;

/* ---- Simulated Weather Generator ---- */
function _simulateWeather(array $city): array {
    $lat = (float)$city['lat'];
    $absLat = abs($lat);

    /* Temperature by latitude band */
    if ($absLat < 15)       $temp = mt_rand(28, 38);
    elseif ($absLat < 30)   $temp = mt_rand(18, 32);
    elseif ($absLat < 45)   $temp = mt_rand(5,  22);
    elseif ($absLat < 60)   $temp = mt_rand(-8, 15);
    else                    $temp = mt_rand(-30, 2);

    $conds = [
        ['desc' => 'Clear sky',        'icon' => '01d', 'id' => 800],
        ['desc' => 'Few clouds',        'icon' => '02d', 'id' => 801],
        ['desc' => 'Scattered clouds',  'icon' => '03d', 'id' => 802],
        ['desc' => 'Broken clouds',     'icon' => '04d', 'id' => 803],
        ['desc' => 'Light rain',        'icon' => '10d', 'id' => 500],
        ['desc' => 'Moderate rain',     'icon' => '10d', 'id' => 501],
        ['desc' => 'Thunderstorm',      'icon' => '11d', 'id' => 211],
        ['desc' => 'Mist',              'icon' => '50d', 'id' => 701],
        ['desc' => 'Overcast clouds',   'icon' => '04d', 'id' => 804],
        ['desc' => 'Light snow',        'icon' => '13d', 'id' => 600],
    ];
    $cond = $conds[array_rand($conds)];

    return [
        'city'         => $city['name'],
        'lat'          => (float)$city['lat'],
        'lon'          => (float)$city['lon'],
        'temperature'  => $temp,
        'feels_like'   => $temp - mt_rand(0, 5),
        'humidity'     => mt_rand(30, 90),
        'pressure'     => mt_rand(1000, 1025),
        'condition'    => $cond['desc'],
        'condition_id' => $cond['id'],
        'icon'         => $cond['icon'],
        'icon_url'     => 'https://openweathermap.org/img/wn/' . $cond['icon'] . '@2x.png',
        'wind_speed'   => round(mt_rand(2, 80) / 10.0, 1),
        'wind_dir'     => mt_rand(0, 359),
        'visibility'   => mt_rand(5000, 10000),
        'cloudiness'   => mt_rand(0, 100),
        'country'      => '',
        'time'         => time(),
        'source'       => 'Simulated',
    ];
}
